
public class D
{
	static void test()
	{
		System.out.println("test");
		System.out.println("test");
		System.out.println("test");
		System.out.println("test");	
	}
public static void main(String[] args)
{
	
	
	test();
	test();
	
}
}
