//Encapsulation

public class A
{
	static int i = 89;
	int j;
	
	public static void main(String[] args)
	{
		A a1 = new A();// object creation
		
		System.out.println("i=" + A.i + " value");
		System.out.println("j=" + a1.j);
	}
}
