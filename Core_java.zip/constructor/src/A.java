public class A
{
	 A()
	{
		// TODO Auto-generated constructor stub
	}
	/*A()
	{
		System.out.println("const1");
	}*/
	/*A(int i)
	{
		System.out.println("const2");
	}
	A(int i, int j)
	{
		System.out.println("const3");
	}*/
	
	public static void main(String[] args)
	{
		A a1 = new A();
		/*A a2 = new A(12);
		A a3 = new A(12, 78);*/
		
		System.out.println("main");
	}
	
}
