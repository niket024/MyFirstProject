public class Account
{
	int accNo;
	int age;
	String name;
	int money;
	
	public Account(int accNo, int age, String name, int money)
	{
		this.accNo = accNo;
		this.age = age;
		this.name = name;
		this.money = money;
	}
	
	public static void main(String[] args)
	{
		Account account = new Account(123, 28, "Niket", 500);
		System.out.println("My details:");
		System.out.println("-------------");
		System.out.println("Account no = " + account.accNo);
		System.out.println("Age = " + account.age);
		System.out.println("Name = " + account.name);
		System.out.println("Money = " + account.money);
		
		account.money =4500;
		
		Account account1 = new Account(222, 45, "abc", 5000);
		System.out.println("My details:");
		System.out.println("-------------");
		System.out.println("Account no = " + account1.accNo);
		System.out.println("Age = " + account1.age);
		System.out.println("Name = " + account1.name);
		System.out.println("Money = " + account1.money);
		
		System.out.println(account.money);
	}
}
