public class A
{
	void test3()
	{
		System.out.println("test3");
	}
	int test()
	{
		System.out.println("test");
		return 12;
	}

	void test1(int i)
	{
		System.out.println(i);
		System.out.println("test1");
	}
	
	int test2(int i)
	{
		System.out.println(i);
		System.out.println("test2");
		return 34;
	}

	public static void main(String[] args)
	{
		A a1 = new A();
//		int result = a1.test();
//		System.out.println(result);
		int reult = a1.test2(12);
		System.out.println(reult);
	}
}
