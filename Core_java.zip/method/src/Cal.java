public class Cal
{
	void add()
	{
		int a = 10;
		int b = 20;
		int sum = a + b;
		System.out.println("sum=" + sum);
	}

	void sub(int a, int b)
	{
		int sub = a - b;
		System.out.println("sub=" + sub);
	}

	int mul()
	{
		int a = 10;
		int b = 20;
		int mul = a * b;
		return mul;
	}

	int div(int a, int b)
	{
		int div = a / b;
		return div;
	}

	public static void main(String[] args)
	{
		Cal c1 = new Cal();
		System.out.println("****CALCULATOR*****");
		c1.add();
		c1.sub(30, 10);
		// int mul = c1.mul();
		System.out.println("mul=" + c1.mul());
		int div = c1.div(100, 20);
		System.out.println("div=" + div);

	}
}
