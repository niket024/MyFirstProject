public class A
{
	int i = 10;

	void test()
	{
		System.out.println("test");
	}
}
