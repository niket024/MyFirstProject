public class A
{
	void test()
	{
		System.out.println("test");
	}

	
	void test(int i)
	{
		System.out.println("test with arg");
	}
	void test(int i, int j)
	{
		System.out.println("test with two arg");
	}
	
	void test(double i)
	{
		System.out.println("test with arg double");
	}
	
	public static void main(String[] args)
	{
		A a1 = new A();
		a1.test(12, 67);
		main(12);
	}
	
	public static void main(int j)
	{
		A a1 = new A();
		a1.test(12, 67);
	}
	
	
}
