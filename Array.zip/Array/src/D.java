public class D
{
	public static void main(String[] args)
	{
		int x[] = new int[3];
		System.out.println(x);
		x[1] = 67;
		System.out.println(x[1]);
		x = new int[5];
		System.out.println(x[1]);
	}
}
// [I