package comparable;

import java.util.Arrays;

public class X
{
	A a111 ;
	public static void main(String[] args)
{
	int a[] = new int [10];
	Arrays.fill(a,10);
	System.out.println( a[0]);
	A a1=null;
	System.out.println(a111);
	System.out.println(Arrays.toString(a));
}
}
