package comparable;

class Z
{

}

public class UserDefinedArray
{
	public static void main(String[] args)
	{
		Z z[] = new Z[5];
		z[0] = new Z();
	}
}
