package com.nik.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil
{
	static Connection connection = null;
	public static Connection getConnection()
	{
		try
		{
			Class.forName("org.h2.Driver");
		} catch (ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		try
		{
			connection = DriverManager.getConnection(
					"jdbc:h2:tcp://localhost/~/test", "sa", "");
		} catch (SQLException e)
		{
			e.printStackTrace();
		}
		return connection;
	}
	
	public static void closeConnection()
	{
		try
		{
			connection.close();
		} catch (SQLException e)
		{
			e.printStackTrace();
		}
	}
}
