package com.nik;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;

import com.nik.util.DBUtil;

public class StudentDAO
{

	public int register(String fName, String lName, String uName, String pwd,
			String skills, String education, String mobile, String gender)
	{
		int status = 0;
		Connection con = DBUtil.getConnection();
		PreparedStatement psmt = null;
		String sql = "insert into student values(?, ?, ?, ?, ?, ?, ?, ?, ?)";
		try
		{
			int regId = getUniqId();
			psmt = con.prepareStatement(sql);
			psmt.setInt(1, regId);
			psmt.setString(2, fName);
			psmt.setString(3, lName);
			psmt.setString(4, uName);
			psmt.setString(5, pwd);
			psmt.setString(6, skills);
			psmt.setString(7, education);
			psmt.setString(8, mobile);
			psmt.setString(9, gender);
			status = psmt.executeUpdate();
			DBUtil.closeConnection();
		} catch (SQLException e)
		{
			e.printStackTrace();
		}

		return status;
	}

	private int getUniqId()
	{
		Random random = new Random();
		return random.nextInt(1000);
	}

	public boolean login(String uname, String pwd)
	{
		boolean status = false;
		Connection con = DBUtil.getConnection();
		PreparedStatement psmt = null;
		String sql = "Select * from Student where username = ? and password =?";
		try
		{
			psmt = con.prepareStatement(sql);
			psmt.setString(1, uname);
			psmt.setString(2, pwd);
			ResultSet rs = psmt.executeQuery();
			if(rs.next())
			{
				status = true;
			}
			DBUtil.closeConnection();
		} catch (SQLException e)
		{
			e.printStackTrace();
		}
		return status;
	}

}
