package com.nik;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class StudentReg extends HttpServlet
{
	private static final long serialVersionUID = 1L;

	public StudentReg()
	{
		super();
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException
	{
		String fName = request.getParameter("fname");
		String lName = request.getParameter("lname");
		String uName = request.getParameter("uname");
		String pwd = request.getParameter("pwd");
		String skills = request.getParameter("skills");
		String education = request.getParameter("education");
		String mobile = request.getParameter("mobile");
		String gender = request.getParameter("gender");
		StudentDAO dao = new StudentDAO();
		int status = dao.register(fName, lName, uName, pwd, skills, education,
				mobile, gender);
		PrintWriter out = response.getWriter();
		if (status > 0)
		{
			out.println("<body bgcolor = 'gray'> ");
			out.print("<h1>Your registration is successfull!!!!</h1><br>");
			out.print("<a href = 'studentLogin.html'><h2>Click here for Login</h2></a><br>");
			out.print("<body>");
		}else{
			out.println("<body bgcolor = 'gray'> ");
			out.print("<h1>Oops!! your registration is failed!!!!</h1><br>");
			out.print("<body>");
		}
	}

}
