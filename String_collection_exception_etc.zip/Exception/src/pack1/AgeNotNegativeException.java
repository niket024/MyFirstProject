package pack1;

public class AgeNotNegativeException extends Exception
{
	String s1 = "pls enter the valid age";

	@Override
	public String toString()
	{
		return s1;
	}

	@Override
	public String getMessage()
	{
		new Thread();
		super.getMessage();
		return s1;
	}
}
