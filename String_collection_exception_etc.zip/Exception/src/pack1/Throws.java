package pack1;

public class Throws
{
	static void test() throws ArithmeticException
	{
		int i = 10 / 0;
	}

	public static void main(String[] args)
	{
		try
		{
			test();

		} catch (ArithmeticException ex)
		{

		}
		System.out.println("main");

	}
}
