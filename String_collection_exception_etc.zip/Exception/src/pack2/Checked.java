package pack2;

import java.sql.SQLException;

public class Checked
{
	public static void main(String[] args) 
	{
		
			try
			{
				Thread.sleep(1000);
			} catch (Throwable e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		
	}
}
