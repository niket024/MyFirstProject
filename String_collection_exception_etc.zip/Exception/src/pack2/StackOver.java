package pack2;

public class StackOver
{
	public static void main(String[] args)
	{
		System.out.println("main");
		main(args);
	}
}
