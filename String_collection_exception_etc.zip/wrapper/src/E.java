public class E
{
	public static void main(String[] args)
	{
		 String s1="10";
	     //String s1 = "hhhh";
		int i = Integer.parseInt(s1);
		double d1 = Double.parseDouble(s1);
		System.out.println("done");
	}
}
