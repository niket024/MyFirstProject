public class I
{
	public static void main(String[] args)
	{
		Integer obj = new Integer(10);
		test(obj);
		test(23);

	}

	static void test(int i)
	{
		System.out.println("done");
	}
}
