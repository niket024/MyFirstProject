public class H
{
	public static void main(String[] args)
	{
		Integer obj1 = 10;// Autoboxing
		int i = obj1;// Autounboxing
		System.out.println(i);
		System.out.println("done");
	}
}
