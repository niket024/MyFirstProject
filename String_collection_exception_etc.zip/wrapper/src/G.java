public class G
{
	public static void main(String[] args)
	{
		int i = 10;
		String s1 = "78";
		Integer obj1 = Integer.valueOf(s1);
		Integer obj2 = Integer.valueOf(i);
		System.out.println("done");
	}
}
