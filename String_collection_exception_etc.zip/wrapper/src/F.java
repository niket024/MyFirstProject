public class F
{
	public static void main(String[] args)
	{
		int i = 10;
		double d = 10.09;
		byte b = 10;
		String s1 = Integer.toString(i);
		String s2 = Double.toString(d);
		String s3 = Byte.toString(b);
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s3);
		System.out.println("done");
	}
}
