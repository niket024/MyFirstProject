package com.pack2;

public class B extends A
{

}
