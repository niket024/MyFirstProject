package com.pack2;

public class D extends C
{
	
}
