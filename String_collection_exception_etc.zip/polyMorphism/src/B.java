public class B extends A
{
	int i = 20;

	@Override
	void test()
	{
		System.out.println("test-B");
	}
}
