public class C extends B
{
	void test()
	{
		System.out.println("test-C");
	}
}
