public class Manager
{
	static void method(A a1)
	{
		a1.test();
	}

	public static void main(String[] args)
	{
		A a1 = new A();
		System.out.println(a1.i);
		method(a1);
		B b1 = new B();
		System.out.println(b1.i);
		method(b1);

	}
}
