package pack2;

import pack1.A;

public class C extends A
{
	public static void main(String[] args)
	{
		C a1 = new C();
		System.out.println(a1.i);
		System.out.println(a1.j);
		System.out.println(a1.k);
		System.out.println(a1.l);
	}
}
