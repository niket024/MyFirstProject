package pack1;

public class A
{
	private int i;
	protected int j;
	int k;
	public int l;
}
