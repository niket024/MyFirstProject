package com.nik;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class StudentLogin extends HttpServlet
{
	private static final long serialVersionUID = 1L;

	public StudentLogin()
	{
		super();
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException
	{
		PrintWriter out = response.getWriter();
		String uname = request.getParameter("uname");
		String pwd = request.getParameter("pwd");
		StudentDAO dao = new StudentDAO();
		boolean isSuccess = dao.login(uname, pwd);
		if(isSuccess)
		{
			request.setAttribute("result", dao.getAllStudents());
			RequestDispatcher dispatcher = request.getRequestDispatcher("loginSuccess.jsp");
			dispatcher.forward(request, response);
		} else {
			out.print("<body bgcolor = 'gray'>");
			out.print("<h1>Your login is Failed!!!!</h1>");
			out.print("<a href ='studentLogin.html'><h2>Please try again</h2></a>");
			out.print("</body>");
		}
	}

}
