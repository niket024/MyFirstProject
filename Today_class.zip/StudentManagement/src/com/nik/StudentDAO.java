package com.nik;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.print.attribute.HashAttributeSet;

import com.nik.util.DBUtil;

public class StudentDAO
{

	public int register(String fName, String lName, String uName, String pwd,
			String skills, String education, String mobile, String gender)
	{
		int status = 0;
		Connection con = DBUtil.getConnection();
		PreparedStatement psmt = null;
		String sql = "insert into student values(?, ?, ?, ?, ?, ?, ?, ?, ?)";
		try
		{
			int regId = getUniqId();
			psmt = con.prepareStatement(sql);
			psmt.setInt(1, regId);
			psmt.setString(2, fName);
			psmt.setString(3, lName);
			psmt.setString(4, uName);
			psmt.setString(5, pwd);
			psmt.setString(6, skills);
			psmt.setString(7, education);
			psmt.setString(8, mobile);
			psmt.setString(9, gender);
			status = psmt.executeUpdate();
			DBUtil.closeConnection();
		} catch (SQLException e)
		{
			e.printStackTrace();
		}

		return status;
	}

	private int getUniqId()
	{
		Random random = new Random();
		return random.nextInt(1000);
	}

	public boolean login(String uname, String pwd)
	{
		boolean status = false;
		Connection con = DBUtil.getConnection();
		PreparedStatement psmt = null;
		String sql = "Select * from Student where username = ? and password =?";
		try
		{
			psmt = con.prepareStatement(sql);
			psmt.setString(1, uname);
			psmt.setString(2, pwd);
			ResultSet rs = psmt.executeQuery();
			if (rs.next())
			{
				status = true;
			}
			DBUtil.closeConnection();
		} catch (SQLException e)
		{
			e.printStackTrace();
		}
		return status;
	}

	public List<Map<String, String>> getAllStudents()
	{
		Connection con = DBUtil.getConnection();
		PreparedStatement psmt = null;
		String sql = "Select * from Student";
		List<Map<String, String>> studentList = new ArrayList<Map<String, String>>();
		try
		{
			psmt = con.prepareStatement(sql);
			ResultSet rs = psmt.executeQuery();
			while (rs.next())
			{
				Map<String, String> studentMap = new LinkedHashMap<String, String>();
				studentMap.put("RegId", new Integer(rs.getInt(1)).toString());
				studentMap.put("FirstName", rs.getString(2));
				studentMap.put("LastName", rs.getString(3));
				studentMap.put("UserName", rs.getString(4));
				studentMap.put("Skills", rs.getString(6));
				studentMap.put("Education", rs.getString(7));
				studentMap.put("Mobile", rs.getString(8));
				studentMap.put("Gener", rs.getString(9));
				studentList.add(studentMap);

			}

			DBUtil.closeConnection();
		} catch (SQLException e)
		{
			e.printStackTrace();
		}

		return studentList;
	}

	public int delete(String regId)
	{
		int status = 0;
		Connection con = DBUtil.getConnection();
		PreparedStatement psmt = null;
		String sql = "delete from Student where RegID =?";
		try
		{
			psmt = con.prepareStatement(sql);
			psmt.setInt(1, Integer.parseInt(regId));
			status = psmt.executeUpdate();
			DBUtil.closeConnection();
		} catch (SQLException e)
		{
			e.printStackTrace();
		}

		return status;
	}

}
