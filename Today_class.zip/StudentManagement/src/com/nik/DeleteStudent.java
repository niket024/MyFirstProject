package com.nik;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DeleteStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
    public DeleteStudent() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		StudentDAO dao = new StudentDAO();
		int status = dao.delete(request.getParameter("regId"));
		if(status> 0)
		{
			RequestDispatcher dispatcher = request.getRequestDispatcher("deleteSuccess.jsp");
			dispatcher.forward(request, response);
		}else{
			System.out.println("Something went wrong");
		}
	}

}
