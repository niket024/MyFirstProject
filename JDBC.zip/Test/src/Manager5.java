import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;


public class Manager5
{
	public static void main(String[] args) throws Exception 
	{
		Class.forName("org.h2.Driver");
		Connection connection = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa", "");
		Statement stmt = connection.createStatement();
		String sql = "delete from test123 where id = 99";
		stmt.executeUpdate(sql);
		connection.close();
		System.out.println("Done");
	}
}
