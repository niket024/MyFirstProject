import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;


public class Manager2
{
	public static void main(String[] args) throws Exception 
	{
		Class.forName("org.h2.Driver");
		Connection connection = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa", "");
		Statement stmt = connection.createStatement();
		String sql = "insert into test123 values(123, 'abc')";
		stmt.executeUpdate(sql);
		connection.close();
		System.out.println("Done");
	}
}
