import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class Manager6
{
	public static void main(String[] args) throws Exception
	{
		Class.forName("org.h2.Driver");
		Connection connection = DriverManager.getConnection(
				"jdbc:h2:tcp://localhost/~/test", "sa", "");
		Statement stmt = connection.createStatement();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the id");
		String id = sc.nextLine();
		String sql = "select * from test123 where id= " + id;
		System.out.println(sql);
		ResultSet rs = stmt.executeQuery(sql);
		while (rs.next()) {
			System.out.println("Id = " + rs.getInt(1));
			System.out.println("Name = " + rs.getString("name"));
			System.out.println("---------------");
		}
		connection.close();
		System.out.println("Done");
	}
}
