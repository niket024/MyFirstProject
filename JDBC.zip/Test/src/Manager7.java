import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class Manager7
{
	public static void main(String[] args) throws Exception
	{
		Class.forName("org.h2.Driver");
		Connection connection = DriverManager.getConnection(
				"jdbc:h2:tcp://localhost/~/test", "sa", "");
		PreparedStatement psmt = connection
				.prepareStatement("select * from test123 where id = ? and name = ?");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the id");
		int id = sc.nextInt();
		psmt.setInt(1, id);

		ResultSet rs = psmt.executeQuery();
		while (rs.next()) {
			System.out.println("Id = " + rs.getInt(1));
			System.out.println("Name = " + rs.getString("name"));
			System.out.println("---------------");
		}
		connection.close();
		System.out.println("Done");
	}
}
