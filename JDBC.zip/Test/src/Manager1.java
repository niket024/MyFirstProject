import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;


public class Manager1
{
	public static void main(String[] args) throws Exception 
	{
		Class.forName("oracle.jdbc.OracleDriver");
		Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:ban83", "cdcadmin", "u_pick_it");
		Statement stmt = connection.createStatement();
		String sql = "Create table test123(id int, name varchar2(20))";
		stmt.execute(sql);
		connection.close();
		System.out.println("Done");
	}
}
