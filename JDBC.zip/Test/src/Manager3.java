import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Scanner;


public class Manager3
{
	public static void main(String[] args) throws Exception 
	{
		Class.forName("org.h2.Driver");
		Connection connection = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa", "");
		Statement stmt = connection.createStatement();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the id");
		int id = sc.nextInt();
		System.out.println("Enter the name");
		String name = sc.next();
		String sql = "insert into test123 values("+id+",'"+name+"')";
		stmt.executeUpdate(sql);
		connection.close();
		System.out.println("Done");
	}
}
