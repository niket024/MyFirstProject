package app1;

public class A
{
	void test()
	{
		System.out.println("Manju");
	}

	public static void main(String[] args)
	{
	 new A()
		{

			void test()
			{
				int count = 0;
				if (count == 0)
				{
					this.test();
				}
				count++;
                test();
				System.out.println("asfdasd");
			}
		};
	}
}
