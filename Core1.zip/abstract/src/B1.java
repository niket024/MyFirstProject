public class B1 extends A
{
	@Override
	public void test(int i)
	{
		// TODO Auto-generated method stub

	}

	@Override
	void test2()
	{
		// TODO Auto-generated method stub

	}
}
