abstract class A
{
	abstract public void test(int i);
	abstract public void test2(int i);
	abstract public void test3(int i);

	void test1()
	{
		System.out.println("test1");
	}

	
}
