public class B extends A
{

	@Override
	public void test(int i)
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void test2(int i)
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void test3(int i)
	{
		// TODO Auto-generated method stub
		
	}
	
	public static void main(String[] args)
	{
		B b1 = new B();
		b1.test1();
	}
	
}
