public  class C extends A implements A1
{
	public void test()
	{
		
	}
}
