
public  class D extends C
{

	@Override
	void test3()
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void test(int i)
	{
		// TODO Auto-generated method stub
		
	}
	
	
}
