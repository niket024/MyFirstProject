public interface A1
{
	abstract public void test();
}
