public class D extends C
{
	@Override
	void test() throws InterruptedException
	{
		// TODO Auto-generated method stub
		super.test();
	}
}
