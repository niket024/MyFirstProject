public class A
{
	public void test()
	{
		System.out.println("test-A");
	}
}
