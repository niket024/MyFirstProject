public class B extends A
{
	@Override
	public void test()
	{
		System.out.println("test-b");
		super.test();
	}
	
	public static void main(String[] args)// signature
	{
		B b1 = new B();
		b1.test();
	}
}
