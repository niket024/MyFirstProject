public interface Vehicle
{
	public abstract void cost();
	public abstract void speed();
	
}
