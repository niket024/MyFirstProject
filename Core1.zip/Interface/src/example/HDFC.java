package example;

public class HDFC implements RBI
{
	@Override
	public int getROI()
	{
		System.out.println("I m from HDFC");
		return 8;
	}
}
