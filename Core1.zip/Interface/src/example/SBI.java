package example;

public class SBI implements RBI
{
	@Override
	public int getROI()
	{
		System.out.println("I m from SBi");
		return 7;
	}
}
