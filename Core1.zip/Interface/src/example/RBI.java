package example;

public interface RBI
{
	int getROI();
}
