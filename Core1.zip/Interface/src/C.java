public interface C extends A
{
	void test3();

}
