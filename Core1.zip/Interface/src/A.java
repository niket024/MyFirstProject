public interface A 
{
	public abstract void test();
	void test1();
	
	
}
