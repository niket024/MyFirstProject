public interface G
{
	int i=90;
	public static final int j = 0;
}
