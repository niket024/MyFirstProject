
public interface E extends A
{
 void test4();
}
