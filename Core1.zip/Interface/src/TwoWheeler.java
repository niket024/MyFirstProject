
public class TwoWheeler implements Vehicle
{

	@Override
	public void cost()
	{
		System.out.println("two wheeler cost:"+10000);
		
	}

	@Override
	public void speed()
	{
		System.out.println("two wheeler spped:"+100 +" kmph");
		
	}
	
}
