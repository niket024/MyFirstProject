package vector.linkedlist;

public class Link
{
	public int data1;
	public Link nextLink;

	public Link(int d1)
	{
		data1 = d1;
		
	}

}
