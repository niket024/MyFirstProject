package set;

import java.util.TreeSet;

public class B
{
	public static void main(String[] args)
	{
		TreeSet set=new TreeSet();
		set.add(12);
		set.add(34);
		//set.add("ggg");
		set.add(67);
		set.add(90);
		set.add(12);
		set.add(12);
		System.out.println(set);
 	}
}
