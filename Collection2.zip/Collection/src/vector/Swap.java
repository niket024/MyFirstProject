package vector;

public class Swap
{
	public static void main(String[] args)
	{
		int a = 8;
		int b = 3;
		int c = a;
		a = b;
		b = c;
		System.out.println(a);
		System.out.println(b);
	}
}
