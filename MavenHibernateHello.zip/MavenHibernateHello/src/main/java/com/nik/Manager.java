package com.nik;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Manager
{
	public static void main(String[] args)
	{
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory factory = configuration.buildSessionFactory();
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		
		Person person = new Person();
		person.setId(676);
		person.setFname("abc");
		person.setLname("xyz");
		person.setAge(45);
		session.save(person);
		
		tx.commit();
		session.flush();
		session.close();
		System.out.println("done");

	}
}
