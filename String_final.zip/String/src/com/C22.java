package com;

public class C22
{
 public static void main(String[] args)
{
	String s1="abc";
	String s2="xyz";
	System.out.println(s1.compareTo(s2));
 
}
}
