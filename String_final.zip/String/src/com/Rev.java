package com;

public class Rev
{
public static void main(String[] hgfhjgjkhkljlkjl)
{
	StringBuffer s1=new StringBuffer();
	s1.append("welcome");
	System.out.println(s1);
	s1.reverse();
	
	System.out.println(s1);
}
}
