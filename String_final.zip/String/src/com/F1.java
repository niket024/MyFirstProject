package com;

public class F1
{
	public static void main(String[] args)
	{

		String s1="abcxyz";
		System.out.println(s1.toUpperCase());
		System.out.println(s1.codePointAt(0));
		System.out.println(s1.contains("c"));
		//System.out.println(s1.);
	}
}
