package com;

public class StringBuff
{
	public static void main(String[] args)
	{
		//legacy
		StringBuffer s1 = new StringBuffer("welcome");
		StringBuffer s2 = new StringBuffer("welcome");
		System.out.println(s1.equals(s2));
		s1.append("abc");
		s1.append("fff");
		s1.append("hhh");
		s1.append("jj");
		s1.append("abkkkc");
		s1.append("jjj");
		s1.append("abkkkc");
	
		System.out.println(s1);
		System.out.println(s1.reverse());

	}

}
