package com;

public class Extract
{
	public static void main(String[] args)
	{
		String s1 = "welcome";
		String s2 = s1.substring(3);
		System.out.println(s2);
		String s4 = s1.substring(2, 5);
		System.out.println(s4);
	}
}
