public class A
{
	final int i = 10;
	public static void main(String[] args)
	{
		 A a1 = new A();
		 //a1.i = 89;
		System.out.println(a1.i);
	}
}
